# ******************************************************************************************************************
# Author - Nirmallya Mukherjee
# Note - this code is provided as is for education purposes and does not carry any warranty.
#        You can use this code in any way you like at your own risk
#
# Apigateway route is /contactme
# ******************************************************************************************************************

import html_page, json

def lambda_handler(event, context):
    print("The incoming data is", json.dumps(event))

    response = {
        "statusCode": 200,
        "statusDescription": "200 OK",
        "isBase64Encoded": False,
        "headers": {
            "Content-Type": "text/html; charset=utf-8"
        }
    }

    response['body'] = html_page.contactme()
    return response
