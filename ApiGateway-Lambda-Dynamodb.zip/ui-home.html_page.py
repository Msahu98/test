# ******************************************************************************************************************
# Author - Nirmallya Mukherjee
# Note - this code is provided as is for education purposes and does not carry any warranty.
#        You can use this code in any way you like at your own risk
# ******************************************************************************************************************

def home_screen():
    return """
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>My Profile</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<style>
		img { border: 1px solid #000; float: left; }
		#contactme:hover { border-radius: 10px; background-color:#DC143C; }
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark">
	  <a class="navbar-brand" href="#">My Profile</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
		<div class="navbar-nav">
		  <a id="contactme" class="nav-item nav-link active" href="#">Contact Me<span class="sr-only">(current)</span></a>
		</div>
	  </div>
	</nav>
	<div class="row" style="margin-top:100px;">
		<div class="col-md-1"></div>
		<div class="col-md-10 text-center border" style="padding:40px;">
			<div>
				<img src="https://img.freepik.com/free-vector/big-data-center-server-room-rack-engineering-process-teamwork-computer-technology-cloud-storage_39422-1032.jpg?size=626&ext=jpg&ga=GA1.2.2012787790.1616560727" height="350px"/>
			</div>
			<div style="margin-left:50%">
				<h4 class="text-center" style="font-weight:bold; font-family:'Courier New', monospace;">What is cloud computing?</h4>
				<p style="text-align:justify; font-size:20px; font-family:Georgia, serif;">Cloud computing is the on-demand delivery of IT resources over the Internet with pay-as-you-go pricing. Instead of buying, owning, and maintaining physical data centers and servers, you can access technology services, such as computing power, storage, and databases, on an as-needed basis from a cloud provider like Amazon Web Services (AWS).</p>
			</div>
		</div>
		<div class="col-md-1"></div>
	</div>
	<footer class="page-footer font-small fixed-bottom bg-dark">
	  <div class="footer-copyright text-center text-white py-3"> © Powered by:
		<a class="text-white" href="http://www.pointernext.com/">pointernext.com </a>
	  </div>
	</footer>
	<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
	<script>
		$(document).ready(function() {
			$("#contactme").attr('href', '/contactme');
		});
	</script>
</body></html>
"""
