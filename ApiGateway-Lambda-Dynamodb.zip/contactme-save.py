# ******************************************************************************************************************
# Author - Nirmallya Mukherjee
# Note - this code is provided as is for education purposes and does not carry any warranty.
#        You can use this code in any way you like at your own risk
#
# Apigateway route is /contactme-save
# Requires DynamoDB table name=contactme and the RK=email_id (String) with Provisioned capacity 1 R/WCU each
# ******************************************************************************************************************

import json, sys, base64, datetime, boto3, random
import urllib.parse
dynamo = boto3.client('dynamodb')

def saveForm(name, emailid):
    dynResp = dynamo.put_item(
        TableName='contactme',
        Item = { 'email_id': {'S': emailid},
                 'user_name': {'S': name},
                 'created_on': {'S': str(datetime.datetime.utcnow())}
        },
        ConditionExpression='not(attribute_exists(user_name))',
        ReturnConsumedCapacity='TOTAL'
    )
    print("Data inserted in DynamoDB", dynResp)


def lambda_handler(event, context):
    try:
        response = {
            "statusCode": 200, "statusDescription": "200 OK", "isBase64Encoded": False,
            "headers": { "Content-Type": "application/json" }
        }
        encBodyData = event['body']
        bodyData = base64.b64decode(encBodyData)
        encFormData = bodyData.decode('utf-8')
        formDict = urllib.parse.parse_qs(encFormData)

		#At this time it saves the list, modify to fetch the first element
        name = formDict.get('fullName')
        Sname = json.dumps(name)

		#At this time it saves the list, modify to fetch the first element
        email = formDict.get('emailId')
        Semail = json.dumps(email)
        saveForm(Sname, Semail)

        respData = {}
        respData['status'] = True;
        respData['message'] = 'saved';

        response['statusCode'] = 200;
        response['body'] = json.dumps(respData);
        return response

    except Exception as e:
        print("Exception is", str(e))
        respData = {}
        respData['status'] = False;
        respData['message'] = str(e);

        response['statusCode'] = 500;
        response['body'] = json.dumps(respData);
        return response
        
        
